//
//  Calculator_LabTests.swift
//  Calculator_LabTests
//
//  Created by Student on 17/07/25.
//

import Testing
@testable import Calculator_Lab

struct Calculator_LabTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
